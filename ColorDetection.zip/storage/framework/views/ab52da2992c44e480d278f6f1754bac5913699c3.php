<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Color Detection</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!-- PWA  -->
    <meta name="theme-color" content="#6777ef"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('logo.PNG')); ?>">
    <link rel="manifest" href="<?php echo e(asset('/manifest.json')); ?>">
</head>
<body class="teal lighten-5">
    <!-- top nav -->
    <nav class="z-depth-0">
        <div class="nav-wrapper container">
        <a href="/">Color <span>Detection</span></a>
        </div>
    </nav>

    

    <div class="col s12 m6">
        <div class="card">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-content">
                    <span class="card-title">
                        <?php if($row->r <= $row->g && $row->r <= $row->b): ?>
                            Color: RED
                        <?php endif; ?>
                        <?php if($row->g <= $row->r && $row->r <= $row->b): ?>
                            Color: GREEN
                        <?php endif; ?>
                        <?php if($row->b <= $row->r && $row->r <= $row->g): ?>
                            Color: BLUE
                        <?php endif; ?>
                    </span>
                    <p><u>Frequency RGB</u></p>
                    <p>R : <?php echo e($row->r); ?>, G : <?php echo e($row->g); ?>, B : <?php echo e($row->b); ?></p>
                </div>
                <div class="card-action">
                    <a href="#"></a>
                    <a class="right" href="#">Date: <?php echo e($row->created_at); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script src="<?php echo e(asset('/sw.js')); ?>"></script>
    <script>
        if (!navigator.serviceWorker.controller) {
            navigator.serviceWorker.register("/sw.js").then(function (reg) {
                console.log("Service worker has been registered for scope: " + reg.scope);
            });
        }
    </script>
    <script>
        setTimeout("location.reload(true);", 5000);
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\ColorDetection\resources\views/home.blade.php ENDPATH**/ ?>